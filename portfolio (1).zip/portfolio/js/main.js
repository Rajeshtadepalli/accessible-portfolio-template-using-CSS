// ===== Theme toggle (light/dark, persisted) =====
(function () {
  const STORAGE_KEY = 'portfolio-theme';
  const root = document.documentElement;
  const toggle = document.querySelector('.theme-toggle');

  function systemPrefersDark() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    if (toggle) {
      toggle.setAttribute('aria-pressed', String(theme === 'dark'));
      toggle.querySelector('.theme-toggle__label').textContent =
        theme === 'dark' ? 'Dark mode' : 'Light mode';
    }
  }

  // On load: use a saved preference if present, otherwise follow the OS.
  let saved = null;
  try {
    saved = localStorage.getItem(STORAGE_KEY);
  } catch (e) {
    /* localStorage unavailable (private browsing, etc.) — fall back silently */
  }
  applyTheme(saved || (systemPrefersDark() ? 'dark' : 'light'));

  if (toggle) {
    toggle.addEventListener('click', () => {
      const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      try {
        localStorage.setItem(STORAGE_KEY, next);
      } catch (e) {
        /* ignore write failures */
      }
    });
  }

  // If the person hasn't chosen explicitly, keep following the OS setting.
  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      let hasSaved = null;
      try {
        hasSaved = localStorage.getItem(STORAGE_KEY);
      } catch (err) { /* noop */ }
      if (!hasSaved) applyTheme(e.matches ? 'dark' : 'light');
    });
  }
})();

// ===== Mobile nav toggle (accessible disclosure pattern) =====
(function () {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.primary-nav');
  if (!toggle || !nav) return;

  const setState = (collapsed) => {
    nav.dataset.collapsed = String(collapsed);
    toggle.setAttribute('aria-expanded', String(!collapsed));
  };

  // Start collapsed on small screens only; CSS handles visibility at wider widths.
  setState(true);

  toggle.addEventListener('click', () => {
    const isCollapsed = nav.dataset.collapsed === 'true';
    setState(!isCollapsed);
  });

  // Close menu after choosing a link (mobile).
  nav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      if (window.innerWidth <= 640) setState(true);
    });
  });
})();

// ===== Accessible contact form validation =====
(function () {
  const form = document.getElementById('contact-form');
  if (!form) return;

  const status = document.getElementById('form-status');

  const fields = [
    {
      input: form.querySelector('#name'),
      error: form.querySelector('#name-error'),
      validate: (v) => v.trim().length > 0,
      message: 'Enter your name.',
    },
    {
      input: form.querySelector('#email'),
      error: form.querySelector('#email-error'),
      validate: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()),
      message: 'Enter a valid email address, like name@example.com.',
    },
    {
      input: form.querySelector('#message'),
      error: form.querySelector('#message-error'),
      validate: (v) => v.trim().length >= 10,
      message: 'Message should be at least 10 characters.',
    },
  ];

  function validateField(field) {
    const value = field.input.value;
    const valid = field.validate(value);
    field.input.setAttribute('aria-invalid', String(!valid));
    field.error.textContent = valid ? '' : field.message;
    return valid;
  }

  fields.forEach((field) => {
    field.input.addEventListener('blur', () => validateField(field));
    field.input.addEventListener('input', () => {
      if (field.input.getAttribute('aria-invalid') === 'true') validateField(field);
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    // Honeypot spam check — bots fill hidden fields, humans never see them.
    const honeypot = form.querySelector('#company');
    if (honeypot && honeypot.value.trim() !== '') {
      return; // silently drop
    }

    const allValid = fields.map(validateField).every(Boolean);

    status.classList.remove('is-success', 'is-error');

    if (!allValid) {
      status.textContent = 'Please fix the highlighted fields before sending your message.';
      status.classList.add('is-error', 'is-visible');
      const firstInvalid = fields.find((f) => f.input.getAttribute('aria-invalid') === 'true');
      if (firstInvalid) firstInvalid.input.focus();
      return;
    }

    // No backend is wired up in this skeleton — replace with a real submission call.
    status.textContent = 'Thanks! Your message has been sent. Maya will reply within two business days.';
    status.classList.add('is-success', 'is-visible');
    form.reset();
    fields.forEach((f) => f.input.removeAttribute('aria-invalid'));
  });
})();
